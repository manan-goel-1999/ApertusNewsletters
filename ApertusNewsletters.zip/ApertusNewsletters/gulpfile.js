var gulp = require('gulp');
var path = require('path');
var fs = require('fs');
var handlebars = require('gulp-handlebars');
var pump = require('pump')
var ncp = require('ncp')
var defineModule = require('gulp-define-module')
var mjml = require('gulp-mjml')
var file = require('gulp-file');

var args = process.argv

var dataDir = path.join(__dirname, './newsletter_data')
var tempDir = path.join(__dirname, './tmp')
var outputDir = path.join(__dirname, './output')

function prepareEnvironment() {
	if (!fs.existsSync(tempDir)) {
		fs.mkdirSync(tempDir)
	}

	if (!fs.existsSync(outputDir)) {
		fs.mkdirSync(outputDir)
	}
}

function checkDataFolder(data) {
	if (!fs.existsSync(path.join(dataDir, data))) {
		console.log('Data folder ' + data + ' not found')
	}
}

function processData(data, cb) {
	var dataAssetsDir = path.join(dataDir, data, '/assets')
	var dataOutputDir = path.join(outputDir, data)
	if (!fs.existsSync(dataOutputDir)) {
		fs.mkdirSync(dataOutputDir)
	}

	// Copy assets to output dir
	ncp(dataAssetsDir, path.join(dataOutputDir, '/assets'), function (err) {
		if (err) {
			return console.error(err);
		}
		console.log('done!');
	});

	pump([
		gulp.src(path.join(__dirname, 'newsletter.mjml')),
		handlebars(),
		defineModule('node'),
		gulp.dest(path.join(tempDir, data))
	],
		cb
	);

	var jsonDataPath = path.join(dataDir, data, 'data.json')
	var jsonData = JSON.parse(fs.readFileSync(jsonDataPath, 'utf8'));

	var handlebarsTemplatePath = path.join(tempDir, data, 'newsletter.js')
	console.log('handlebarsTemplatePath: ' + handlebarsTemplatePath)
	var appTemplate = require(handlebarsTemplatePath);
	var html = appTemplate(jsonData);
	var mjmlTemplatePath = path.join(tempDir, data, 'newsletter.mjml')
	fs.writeFileSync(mjmlTemplatePath, html)
	
	gulp.src(mjmlTemplatePath)
		.pipe(mjml())
		.pipe(gulp.dest(path.join(outputDir, data)));
}

gulp.task('default', function (cb) {
	if (process.argv[2] == null || process.argv[2] != '--data' || process.argv[3] == null) {
		console.log("No data was provided. Usage: gulp --data <data folder name>")
	}

	var dataFolder = process.argv[3]
	prepareEnvironment();
	checkDataFolder(dataFolder);
	processData(dataFolder, cb);
})

